<?php
defined('IN_ADMIN') or exit('No permission resources.');
include $this->admin_tpl('header');?> 
<a href="<?php echo $thumb;?>" target="_blank"><Img src="<?php echo $thumb;?>" title="点击打开大图" width="500" height="450"></a>
</body> 
</html>
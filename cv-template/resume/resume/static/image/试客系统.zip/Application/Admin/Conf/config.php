<?php 
return array (
	/* 创始人ID */
	'ADMIN_FOUNDERS'	   => '1',
	'DEFAULT_ACTION'       => 'init',
	'DEFAULT_THEME'        => '',
	
	'TMPL_ENGINE_TYPE'     => 'Think',
	'TAGLIB_BEGIN'         => '<',
	'TAGLIB_END'           => '>',
	'TAGLIB_NAME'          => '',

	'DEFAULT_CONTROLLER'   => 'Index',
	//'DEFAULT_ACTION'       => 'init',
	// 'SHOW_PAGE_TRACE'	 => FALSE,

	
	'SETTING_GROUP_CONFIG' => array(
		'base'		=> '基本设置',
		'safe'		=> '安全设置',
		'email' 	=> '邮件设置',
		'upload'	=> '上传配置'
	),
);
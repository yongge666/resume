<?php defined('IN_ADMIN') or exit('No permission resources.');?>
<?php include $this->admin_tpl('header', 'admin');?>
<div class="pad-lr-10">
<form action="<?php echo __APP__;?>" method="get">
<input type="hidden" value="<?php echo MODULE_NAME; ?>" name="m">
<input type="hidden" value="<?php echo CONTROLLER_NAME; ?>" name="c">
<input type="hidden" value="<?php echo ACTION_NAME; ?>" name="a">
<input type="hidden" value="<?php echo MENUID; ?>" name="menuid">
<table width="100%" cellspacing="0" class="search-form">
    <tbody>
        <tr>
            <td>
                <div class="explain-col">
                                排序方式：
                <select name="sort">
                    <option value="add_merchant" <?php if($_GET['sort'] == 'add_merchant'){?>selected<?php }?>>新增商家</option> 
                    <option value="vip_total_money" <?php if($_GET['sort'] == 'vip_total_money'){?>selected<?php }?>>升级vip总费用</option>
                    <option value="cash_count" <?php if($_GET['sort'] == 'cash_count'){?>selected<?php }?>>缴纳保证金</option>   
                </select>
                <input type="submit" name="search" class="button" value="<?php echo L('search')?>" />
                </div>
            </td>
        </tr>
    </tbody>
</table>
</form> 

<form name="myform" action="<?php echo U('delete');?>" method="post" onsubmit="checkuid();return false;">
<div class="table-list">
<table width="100%" cellspacing="0">
    <thead>
        <tr>
            <th align="left">排名</th>
            <th align="left">业务员</th>
            <th align="left">业务id</th>
            <th align="left">今日新增商家</th>
            <?php foreach ($merchant_type as $k=>$t){?>
            <?php if($t['groupid'] != 1){?>
            <th align="left">升级续费/<?php echo $t['name'];?></th>
            <?php }}?>
            <th align="left">升级vip费用总计</th>         
            <th align="left">商家发布试用活动</th>
            <th align="left">商家发布返利活动</th>
            <th align="left">今日总缴纳保证金</th>
            <th align="left">操作</th>
        </tr>
    </thead>
<tbody>
<?php 
if(is_array($attract_lists)){
    foreach ($attract_lists as $k=>$a){
?>
    <tr>
        <td align="left"><?php echo $k+1;?></td>
        <td align="left"><?php echo $a['username'];?></td>
        <td align="left"><?php echo $a['userid'];?></td>
        <td align="left"><?php echo $a['add_merchant'];?>名商家</td>
        <?php foreach ($merchant_type as $_k=>$ty){?>
        <?php if($ty['groupid'] != 1){
            $b = $_k - 2;
         ?>
        <td align="left">
        <?php echo $a['group'][$b]['count'];?>人/<?php echo substr($ty['pricetype'],strpos($ty['pricetype'],',') + 1);?>元<br />
                费用总计：<?php echo $a['group'][$b]['money'];?>
        </td>
        <?php }}?>
        <td align="left"><?php echo $a['vip_total_money'];?>元</td>
        <td align="left">
                总计：<?php if($a['m_count']){echo $a['m_count'];}else{echo 0;}?>名商家 发布活动<?php if($a['a_num']){echo $a['a_num'];}else{echo 0;}?>个<br />
                总计：已成功缴纳保证金<?php if($a['cash']){echo $a['cash'];}else{echo 0;}?>元    
        </td>
        <td align="left">
                总计：<?php if($a['r_m_count']){echo $a['r_m_count'];}else{echo 0;}?>名商家 发布活动<?php if($a['r_a_num']){echo $a['r_a_num'];}else{echo 0;}?>个<br />
                总计：已成功缴纳保证金<?php if($a['r_cash']){echo $a['r_cash'];}else{echo 0;}?>元 
        </td>
        <td align="left"><?php echo $a['cash_count'];?>元</td>
        <td>
            <a href="<?php echo U('Admin/Statistics/history',array('userid'=>$a['userid']));?>" >[历史记录]</a>
        </td>
    </tr>
    <?php }}?>
</tbody>
</table>
<div id="pages"><?php echo $pages?></div>
</div>
</form>
</div>
<script type="text/javascript">
<!--
function edit(obj, name) {
    window.top.art.dialog({id:'edit'}).close();
    window.top.art.dialog({title:'<?php echo L('edit').L('member')?>《'+name+'》',id:'edit',iframe:obj.href,width:'700',height:'500'}, function(){var d = window.top.art.dialog({id:'edit'}).data.iframe;d.document.getElementById('dosubmit').click();return false;}, function(){window.top.art.dialog({id:'edit'}).close()});
}
function checkuid() {
    var ids='';
    $("input[name='ids[]']:checked").each(function(i, n){
        ids += $(n).val() + ',';
    });
    if(ids=='') {
        window.top.art.dialog({content:'请勾选你要删除的记录',lock:true,width:'200',height:'50',time:1.5},function(){});
        return false;
    } else {
        myform.submit();
    }
}
function member_infomation(userid) {
    window.top.art.dialog({id:'modelinfo'}).close();
    window.top.art.dialog({title:'处理申诉',id:'modelinfo',iframe:'?m=Order&c=Appeal&a=appeal_do&appeal_id='+userid,width:'700',height:'500'}, function(){var d = window.top.art.dialog({id:'modelinfo'}).data.iframe;d.document.getElementById('dosubmit').click();return false;}, function(){window.top.art.dialog({id:'modelinfo'}).close()});
}
//-->
</script>
</body>
</html>
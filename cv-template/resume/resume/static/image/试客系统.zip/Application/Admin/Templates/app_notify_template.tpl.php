<?php
defined('IN_ADMIN') or exit('No permission resources.');
$show_header = True;
include $this->admin_tpl('header');?>
<script  type="text/javascript" src="<?php echo JS_PATH?>formvalidator.js" charset="UTF-8"></script>
<script  type="text/javascript" src="<?php echo JS_PATH?>formvalidatorregex.js" charset="UTF-8"></script>
<style type="text/css">
.input-botton {
    border:none;
    border-bottom:1px dotted #E1A035;
    background:none;
}
</style>
<script type="text/javascript">
$(function(){
    $('.input-botton').click(function(){
        $(this).select();
    })
})
</script>
<form action="<?php echo U('config');?>" method="post" id="myform">
<div class="pad-10">
    <div class="col-tab">
        <fieldset>
        <legend>app通知模板配置</legend>    
        <table width="100%"  class="table_form">
           
           
           
            <tr>
                <th>充值处理结果</th>
                <td>
                    <label><input type="checkbox" name="configs[app_pay_recharge_check][]" value="message" <?php if(preg_match("/message/",$configs['app_pay_recharge_check']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_pay_recharge_check][]" value="email" <?php if(preg_match("/email/",$configs['app_pay_recharge_check']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_pay_recharge_check][]" value="sms" <?php if(preg_match("/sms/",$configs['app_pay_recharge_check']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                    <!-- &nbsp;<em style="vertical-align:middle;">普通充值审核结果通知</em> -->
                </td>
            </tr>
            <tr>
                <th>提现处理结果</th>
                <td>
                    <label><input type="checkbox" name="configs[app_pay_cash_check][]" value="message" <?php if(preg_match("/message/",$configs['app_pay_cash_check']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_pay_cash_check][]" value="email" <?php if(preg_match("/email/",$configs['app_pay_cash_check']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_pay_cash_check][]" value="sms" <?php if(preg_match("/sms/",$configs['app_pay_cash_check']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th width="120">商品审核结果通知</th>
                <td>
                    <label><input type="checkbox" name="configs[app_product_check][]" value="message" <?php if(preg_match("/message/",$configs['app_product_check']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_product_check][]" value="email" <?php if(preg_match("/email/",$configs['app_product_check']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_product_check][]" value="sms" <?php if(preg_match("/sms/",$configs['app_product_check']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>商品被屏蔽通知</th>
                <td>
                    <label><input type="checkbox" name="configs[app_product_lock][]" value="message" <?php if(preg_match("/message/",$configs['app_product_lock']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_product_lock][]" value="email" <?php if(preg_match("/email/",$configs['app_product_lock']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_product_lock][]" value="sms" <?php if(preg_match("/sms/",$configs['app_product_lock']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>商品结算通知</th>
                <td>
                    <label><input type="checkbox" name="configs[app_product_balance][]" value="message" <?php if(preg_match("/message/",$configs['app_product_balance']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_product_balance][]" value="email" <?php if(preg_match("/email/",$configs['app_product_balance']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_product_balance][]" value="sms" <?php if(preg_match("/sms/",$configs['app_product_balance']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>用户填写订单号</th>
                <td>
                    <label><input type="checkbox" name="configs[app_order_fill_trade_no][]" value="message" <?php if(preg_match("/message/",$configs['app_order_fill_trade_no']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_order_fill_trade_no][]" value="email" <?php if(preg_match("/email/",$configs['app_order_fill_trade_no']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_order_fill_trade_no][]" value="sms" <?php if(preg_match("/sms/",$configs['app_order_fill_trade_no']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>用户填写试用报告</th>
                <td>
                    <label><input type="checkbox" name="configs[app_order_fill_report][]" value="message" <?php if(preg_match("/message/",$configs['app_order_fill_report']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_order_fill_report][]" value="email" <?php if(preg_match("/email/",$configs['app_order_fill_report']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_order_fill_report][]" value="sms" <?php if(preg_match("/sms/",$configs['app_order_fill_report']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>用户订单审核结果</th>
                <td>
                    <label><input type="checkbox" name="configs[app_order_check_trade_no][]" value="message" <?php if(preg_match("/message/",$configs['app_order_check_trade_no']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_order_check_trade_no][]" value="email" <?php if(preg_match("/email/",$configs['app_order_check_trade_no']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_order_check_trade_no][]" value="sms" <?php if(preg_match("/sms/",$configs['app_order_check_trade_no']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>订单结算通知</th>
                <td>
                    <label><input type="checkbox" name="configs[app_order_balance][]" value="message" <?php if(preg_match("/message/",$configs['app_order_balance']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_order_balance][]" value="email" <?php if(preg_match("/email/",$configs['app_order_balance']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_order_balance][]" value="sms" <?php if(preg_match("/sms/",$configs['app_order_balance']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>用户发起申诉</th>
                <td>
                    <label><input type="checkbox" name="configs[app_order_appeal][]" value="message" <?php if(preg_match("/message/",$configs['app_order_appeal']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_order_appeal][]" value="email" <?php if(preg_match("/email/",$configs['app_order_appeal']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_order_appeal][]" value="sms" <?php if(preg_match("/sms/",$configs['app_order_appeal']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
            <tr>
                <th>申诉仲裁结果</th>
                <td>
                    <label><input type="checkbox" name="configs[app_order_appeal_arbitration][]" value="message" <?php if(preg_match("/message/",$configs['app_order_appeal_arbitration']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_order_appeal_arbitration][]" value="email" <?php if(preg_match("/email/",$configs['app_order_appeal_arbitration']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_order_appeal_arbitration][]" value="sms" <?php if(preg_match("/sms/",$configs['app_order_appeal_arbitration']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>

             <tr>
                <th>补仓功能提醒</th>
                <td>
                    <label><input type="checkbox" name="configs[app_goods_notify][]" value="message" <?php if(preg_match("/message/",$configs['app_goods_notify']['type'])) : ?>checked="checked"<?php endif ?>> 站内信</label>
                    <label><input type="checkbox" name="configs[app_goods_notify][]" value="email" <?php if(preg_match("/email/",$configs['app_goods_notify']['type'])) : ?>checked="checked"<?php endif ?>> 邮件通知</label>
                    <label><input type="checkbox" name="configs[app_goods_notify][]" value="sms" <?php if(preg_match("/sms/",$configs['app_goods_notify']['type'])) : ?>checked="checked"<?php endif ?>> 手机短信</label>
                </td>
            </tr>
        </table>
        </fieldset>
        <div class="bk15"></div>
        <input name="dosubmit" type="submit" value="<?php echo L('submit')?>" class="button">
    </div>
</div>
</form>
</body>
<script type="text/javascript">
function SwapTab(name,cls_show,cls_hide,cnt,cur) {
    $('div.contentList').hide();
    $('ul.tabBut > li').attr('class', cls_hide);
    $('#div_'+name+'_'+cur).show();
    $('#tab_'+name+'_'+cur).attr('class',cls_show);
}
</script>
</html>
<?php 
return array(
	'comments_module_configuration'        => '评论模块配置',
	'comment_on_whether_to_allow_visitors' => '是否允许游客评论',
	'check_comment'                        => '是否需要审核',
	'whether_to_validate'                  => '是否开启验证码',

'comments_on_points_awards' => '评论积分奖励',
'be_deleted_from_the_review_points' => '评论被删除扣除积分',

'to_operate' => ' 分，0为不操作。',
);
?>
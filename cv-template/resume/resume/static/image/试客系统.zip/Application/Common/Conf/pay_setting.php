<?php 
 return array (
  'QUICK' => 'array (
  \'time\' => \'3小时\',
  \'service\' => 
  array (
    \'common\' => \'1\',
    \'vip\' => \'1\',
  ),
)',
  'COMMON' => 'array (
  \'time\' => \'6小时\',
)',
);
?>
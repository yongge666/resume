<?php return array (
  'SYSTEM_IDENTIFIER' => 'pro.cloud',
  'SYSTEM_VERSION' => '1.9.16',
  'SYSTEM_RELEASE' => '20150917',
  'SYSTEM_FIXBUG' => '00000046',
);?>


<?php 
 return array (
  'BONUS_ISOPEN' => '1',
  'BONUS_NAME' => '红包试用',
  'BONUS_PRICE' => 'array (
  \'min\' => \'1 \',
  \'max\' => \'100\',
)',
  'BONUS_CONTENT' => '红包',
);
?>
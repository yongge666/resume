<?php 
 return array (
  'seller_charge_name' => '推广费',
  'single_mode' => 'array (
  \'seller_general_order\' => \'1\',
  \'seller_search_order\' => \'1\',
  \'seller_answer_order\' => \'1\',
  \'seller_qrcode_order\' => \'1\',
)',
  'seller_give_back' => '1',
  'seller_ordersn_check' => '23',
  'seller_check_time' => '7',
  'trial_name' => '免费试用',
  'seller_charge_money' => '0',
  'seller_trialtalk_check' => 'array (
  \'value\' => \'15\',
  \'chose\' => \'1\',
)',
  'buyer_join_condition' => 'array (
  \'information\' => \'6\',
)',
  'buyer_write_order_time' => '48',
  'buyer_good_buy_times' => '1',
  'buyer_day_buy_times' => '0',
  'buyer_write_talk_time' => '15',
  'buyer_check_update_order_sn' => '72',
  'seller_end_time' => '2019-01-30',
  'seller_start_time' => '2015-01-08',
  'seller_activity_desc' => '单个商品参团，高价值商品优先，审核通过后获得排期，活动时间最长30天，',
  'seller_detail_desc' => '单个商品页面显示，高性价比优先。<br />
',
  'trial_isopen' => '1',
  'trial_price_name' => '试用价',
  'seller_join_condition' => 'array (
  \'phone\' => \'1\',
  \'email\' => \'2\',
  \'realname\' => \'3\',
  \'information\' => \'6\',
)',
  'bonus_isopen' => '1',
  'bonus_name' => '红包试用',
  'bonus_price' => 'array (
  \'min\' => \'1 \',
  \'max\' => \'100\',
)',
  'bonus_exchange' => '1',
  'bonus_ratio' => '1:0.5',
  'bonus_content' => '红包',
  'seller_pat_isopen' => '1',
  'seller_bonus_isopen' => '1',
);
?>
<?php return array (
  'SYSTEM_IDENTIFIER' => 'pro.cloud',
  'SYSTEM_VERSION' => '1.9.5',
  'SYSTEM_RELEASE' => '20150602',
  'SYSTEM_FIXBUG' => '00000037',
);?>
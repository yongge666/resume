<?php
/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2013, Chongqing Zero Technology Co. Ltd.
 * @link           http://www.xuewl.com
**/
namespace Common\Library;
class app {
	
	public static function load_sys_class() {
		return '1234';
	}

	public static function load_app_func() {
	}

	public static function load_app_class($classname, $path = '') {

	}

	public static function load_config() {
		
	}
}
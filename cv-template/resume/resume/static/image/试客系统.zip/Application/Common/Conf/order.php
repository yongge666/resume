<?php 
 return array (
  'ORDER_TYPE' => 
  array (
    'GENERAL_ORDER' => 
    array (
      'name' => '普通下单图章',
      'ico' => './uploadfile/2014/1222/20141222032641962.jpg',
      'desc' => '',
    ),
    'SEARCH_ORDER' => 
    array (
      'name' => '搜索下单图章',
      'ico' => './uploadfile/2014/1222/20141222032645376.jpg',
      'desc' => '',
    ),
    'ANSWER_ORDER' => 
    array (
      'name' => '答案下单图章',
      'ico' => '',
      'desc' => '',
    ),
    'QR_ORDER' => 
    array (
      'name' => '二维码下单图章',
      'ico' => '',
      'desc' => '',
    ),
  ),
);
?>
<?php 
 return array (
  'postal_name' => '九块九包邮',
  'seller_charge_name' => '推广费',
  'seller_charge_money' => '5',
  'seller_start_time' => '2015-01-08',
  'seller_end_time' => '2018-01-31',
  'seller_activity_desc' => '单个商品参团，高性价比优先。报名价格需≥29元，审核通过后获得排期，活动时间最长报名30 天。',
  'seller_detail_desc' => '<table border="1" class="table">
<thead>
	<tr>
	<th>
		标准</th>
	<th>
		集市卖家</th>
	<th>
		天猫卖家</th>
	</tr>
</thead>
<tbody>
	<tr>
	<td>信誉等级</td>
	<td>2钻及以上</td>
	<td>不限</td>
	</tr>
	<tr>
	<td>动态评分</td>
	<td>同行持平以上</td>
	<td>同行持平以上</td>
	</tr>
	<tr>
	<td>报名数量</td>
	<td>》200件</td>
	<td>》200件</td>
	</tr>
	<tr>
	<td>商品评价</td>
	<td>&gt;10条</td>
	<td>&gt;10条</td>
	</tr>
	<tr>
	<td>是否样品</td>
	<td>酌情收取</td>
	<td>酌情收取</td>
	</tr>
	<tr>
	<td>发货速度</td>
	<td>1-3日发货</td>
	<td>1-3日发货</td>
	</tr>
	<tr>
	<td>历史价格</td>
	<td>&gt;本期活动价</td>
	<td>&gt;本期活动价</td>
	</tr>
	<tr>
	<td>审核周期</td>
	<td>&gt;15个工作日</td>
	<td>&gt;15个工作日</td>
	</tr>
	<tr>
	<td>预告方式</td>
	<td>&gt;需预告、无预告</td>
	<td>&gt;需预告、无预告</td>
	</tr>
	<tr>
	<td>重复周期</td>
	<td>&gt;15天后</td>
	<td>&gt;15天后</td>
	</tr>
	<tr>
	<td>店内客服</td>
	<td>&gt;必须在线</td>
	<td>&gt;必须在线</td>
	</tr>
</tbody>
</table>
<br />
',
  'postal_isopen' => '1',
  'postal_price_name' => '包邮价',
);
?>
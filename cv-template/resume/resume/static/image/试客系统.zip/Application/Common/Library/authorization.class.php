<?php
//zend53   
//Decode by www.dephp.cn  QQ 2859470
?>
<?php

namespace Common\Library;

class authorization
{
	protected $host = "";
	protected $file = "";
	protected $error = "";
	protected $key = "";
	protected $code = "";

	public function __construct()
	{
		$this->host = strtolower($_SERVER["HTTP_HOST"]);
		$this->key = $this->parse_url();
		$md5 = md5($this->key);
		$this->key = substr($md5, 0, 10) . $md5 . substr($md5, 22);
		$this->file = CONF_PATH . "authorize.key";
		$this->getLocalKey();
		$this->sendAuthorization();
	}

	public function check()
	{
		

		$this->writeAuthFile();
		return TRUE;
	}

	public function getRemoteKey()
	{
		

			return TRUE;
	}

	public function getLocalKey()
	{
		
		return TRUE;
	}

	public function getDecodeKey($code)
	{
		$this->code = unserialize(authcode($code, "DECODE", $this->key));
		return TRUE;
	}

	public function writeAuthFile()
	{
		if ($this->code) {
			$auth = $this->code;
			$auth["update_time"] = NOW_TIME;
			@file_put_contents($this->file, authcode(serialize($auth), "ENCODE", $this->key));
		}

		return TRUE;
	}

	private function parse_url($host = "")
	{
		$host = (empty($host) ? $this->host : $host);

		if (empty($host)) {
			return NULL;
		}

		$regx1 = "/(([^\/\?#&]+\.)?([^\/\?#&\.]+\.)(com\.cn|org\.cn|net\.cn|com\.jp|co\.jp|com\.kr|com\.tw)(\:[0-9]+)?)\/?/i";
		$regx2 = "/(([^\/\?#&]+\.)?([^\/\?#&\.]+\.)(cn|com|org|info|us|fr|de|tv|net|cc|biz|hk|jp|kr|name|me|tw|la)(\:[0-9]+)?)\/?/i";
		$tophost = "";

		if (preg_match($regx1, $host, $matches)) {
			$host = $matches[1];
		}
		else if (preg_match($regx2, $host, $matches)) {
			$host = $matches[1];
		}

		if ($matches) {
			$tophost = $matches[3] . $matches[4];
			$domainLevel = ($matches[2] == "www." ? 1 : substr_count($matches[2], ".") + 1);
		}
		else {
			$tophost = "";
			$domainLevel = 0;
		}

		return $tophost;
	}

	public function sendAuthorization()
	{
		$lastSend = getcache("__last__", "commons");
		if (isset($lastSend) && ((86400 * 7) < (NOW_TIME - $lastSend))) {
			helpers("authorization");
			sendauthorization("used");
			setcache("__last__", NOW_TIME, "commons");
		}
	}

	public function getError()
	{
		

		return false;
	}
}


?>

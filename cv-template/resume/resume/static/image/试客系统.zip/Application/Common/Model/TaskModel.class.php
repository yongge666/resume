<?php
namespace Common\Model;
class TaskModel extends \Think\Model {
}

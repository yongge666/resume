<?php 
/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2013, Chongqing Zero Technology Co. Ltd.
 * @link           http://www.xuewl.com
**/
namespace Common\Model;
use Think\Model;
Class HitsModel extends Model {
	/*自动验证*/
	protected $_validate = array (
	);

	protected $_auto = array (
		
	);
}
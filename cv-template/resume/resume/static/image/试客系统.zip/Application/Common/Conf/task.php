<?php 
 return array (
  'TASK_ISOPEN' => '1',
  'TASK_PRICE' => '0.1',
  'TASK_NUM' => '50',
  'TASK_CONTENT' => '日赚任务介绍',
  'TASK_IMG' => 'a',
);
?>
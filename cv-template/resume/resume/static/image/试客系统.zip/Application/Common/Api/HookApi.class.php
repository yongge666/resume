<?php
/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2014, Chongqing xuewl Information Technology Co., Ltd.
 * @link           http://www.xuewl.com
**/
namespace Common\Api;
use Common\Api\Api;

class HookApi extends Api{
    /* 构造方法 */
    protected function init(){
        $this->modules = getcache('module', 'commons');
    }

    /* 嵌入点简易实现方法 */
    public function run($hookid, $param = '') {
        if (!$this->modules) return FALSE;
        $modules = array_keys($this->modules);
        foreach ($modules as $module) {
            $class_path = "\\".ucfirst($module)."\\Library\\hook";
            if(!class_exists($class_path)) continue;
            $Hook = new $class_path();
            if(!method_exists($Hook, $hookid)) continue;
            $Hook->$hookid($param);
        }
    }
}
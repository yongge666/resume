	function groupid($field, $value) {
		if($value) $value = explode(',',$value);
		return $value;
	}

	function picfile($field, $value) {
		return unserialize($value);
	}

	function images($field, $value) {
		return unserialize($value);
		//return string2array($value);
	}

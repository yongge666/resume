<?php 
namespace Api\Controller;
use \Common\Controller\BaseController;
header('Access-Control-Allow-Origin: *');

/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2013, Chongqing Zero Technology Co. Ltd.
 * @link           http://www.xuewl.com
**/
class AppController extends BaseController {
    public function _initialize() {
        parent::_initialize(); 
        $this->message_db = model('message');
        $this->mgroup_db = model('message_group');
    }
    /**
     * api获取商品列表信息
     * @author xuewl <master@xuewl.com>
     */
     public function goodslists() {
        $param = I('param.');
        extract($param);
        $catid = max(0, (int) $catid);
        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
        $keyword = remove_xss($keyword);
        $sqlmap = array();
        if($mod == 'trial'){
            $protype = isset($protype) ? (int) $protype : -1;
            /*protype: 0 :[实物专区] 1 :[拍a发b] 2 :[红包专区]*/
            if($protype > -1){
                if($protype == 0){
                    //$sqlmap['t.goods_tryproduct'] = array('EQ','0');
                   $sqlmap['t.goods_tryproduct'] =  array(array('EQ','0'),array('EQ',''), 'or');  
                   $sqlmap['t.goods_bonus'] = array('EQ','0.00');

                }else if($protype==1){
                    $sqlmap['t.goods_tryproduct'] =array(array('NEQ','0'),array('NEQ',''), 'and');
                    $sqlmap['t.goods_bonus'] = array('EQ','0.00');

                }else if($protype == 2) {
                    $sqlmap['t.goods_bonus'] = array('NEQ','0.00');
                    $sqlmap['t.goods_tryproduct'] =  array(array('EQ','0'),array('EQ',''), 'or');  


                }
             }else{
                //$sqlmap['t.goods_bonus'] = array('NEQ','0');
             }
        }
       
        if ($type == 1) {
            $sqlmap['t.goods_price'] = array(array('EGT',0),array('ELT',3)) ;
           
        }
       

        if ($source) {
            $sqlmap['t.source'] = array('EQ',$source);
        }
         if ($isrecommend) {
            $sqlmap['p.isrecommend'] = array('EQ',$isrecommend);
        }

        if(isset($status)){
            $sqlmap['p.status'] = $status;
        }else{
            $sqlmap['p.status'] = 1;
            $sqlmap['p.start_time'] = array("LT", NOW_TIME);
            $sqlmap['p.end_time'] = array("GT", NOW_TIME);
        }
        if($mod && in_array($mod, array('rebate', 'postal', 'trial'))) {
            $sqlmap['p.mod'] = $mod;
        }
        
        if($keyword) {
            if($type == 'c') {
                $com_map = array();
                $com_map['store_name'] = array("LIKE", "%".$keyword."%");
                $company_ids = model('member_merchant')->where($com_map)->getField('userid', TRUE);                
                if(!$company_ids) {
                    $this->error('没有任何内容');
                }
                $sqlmap['p.company_id'] = array("IN", $company_ids);
            } else {
                $sqlmap['p.title|p.keyword'] = array("LIKE", "%".$keyword."%");
            }   
        }
        
        $company_id = (int) $company_id;
        if($company_id > 0) {
            $sqlmap['p.company_id'] = $company_id;
        }
       
        if($catid > 0) {
            $categorys = getcache('product_category', 'commons');
            $category = $categorys[$catid];
            $catids = $category['arrchildid'];
            if($catids) {
                $sqlmap['p.catid'] = array("IN", $catids);
            } else {
                $this->error('没有内容');
            }
        }   

        if ($orderby == '' || $orderway == ''){
            $orderby = 'id';
            $orderway = 'desc';
        }else{
            if ($orderby == 'id' ||$orderby == 'start_time' ||$orderby == 'hits' ) {
                $orderby  = 'p.'.$orderby;
            }else{
                $orderby  = 't.'.$orderby;
            }
        }
      
        if($mod){
            $count = model('product')->alias('p')->join(C('DB_PREFIX').'product_'.$mod.' AS t ON p.id = t.id')->where($sqlmap)->count();
            $ids = model('product')->alias('p')->join(C('DB_PREFIX').'product_'.$mod.' AS t ON p.id = t.id')->where($sqlmap)->page($page, $num)->field('p.id')->order($orderby.' '.$orderway)->select();

           // echo model('product')->getLastSql();
        }else{
            $sqlmap['p.mod'] = array('NEQ','trial');
            $count = model('product')->alias('p')->where($sqlmap)->count();
            $ids = model('product')->alias('p')->where($sqlmap)->field('p.id')->page($page, $num)->order($orderby.' '.$orderway)->select();

        }
        
        if(!$ids) $this->error('没有找到商品');
        $lists = array();
        foreach($ids as $k=>$v) {
            $factory = new \Product\Factory\product($v['id']);
            $rs = $factory->product_info;
            $r['mod_name'] = model('activity_set')->where(array('key' => $rs['mod'].'_name'))->getField('value');
            $r['price_name'] = activitiy_price_name($rs['mod']);
            $r['mod_price'] = price($rs['id']);
            $r['number'] = $rs['goods_number'] - buyer_count_by_gid($rs['id']);//剩余份数
            $r['start_time'] = $rs['start_time'];
            $r['title'] = $rs['title'];
            $r['get_trial'] = get_trial_by_gid($rs['id']); //已申请人数
            $r['catid'] = $rs['catid'];
            $r['id'] = $rs['id'];
            $r['thumb'] = $rs['thumb'];
            if ($rs['mod'] == 'rebate') {
                $r['price'] = $rs['goods_price']*$rs['goods_discount'];
            }
            $r['goods_price'] = $rs['goods_price'];
            $r['goods_bonus'] = $rs['goods_bonus'];
            $r['hits'] = $rs['hits'];
             $r['goods_tryproduct'] = $rs['goods_tryproduct'];
            if ($rs['mod'] == 'trial') {
                
                if ($rs['goods_bonus'] > '0' && $rs['goods_bonus'] != '0.00') {
                    /*3:红包类型*/
                    $r['protype'] = 3;
                }elseif($rs['goods_tryproduct'] > 0 && $rs['goods_tryproduct'] != ''){
                        /*w:拍a发b*/
                    $r['protype'] = 2;
                }else{
                        /*1:实物专区*/
                    $r['protype'] = 1;

                }

            }

            $lists[$k] = $r;
        }

      //  print_r($lists);

        $pages = page($count, $num);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);
    }

    /*产品分类表*/
    public function goods_categorylists(){
        $param = I('param.');
        extract($param);       
        $sqlmap = array();
        if(!empty($where)){
            $sqlmap['_string'] = $where;
        }else{
            $catid = (empty($catid)) ? 0 : $catid;
            if(strpos($catid, ',') === FALSE) {
                $catid = (int) $catid;
                $catid = ($catid < 1) ? 0 : $catid;
                $sqlmap['parentid'] = $catid;
            } else {
                $sqlmap['catid'] = array("IN", $catid);
            }
        }
        $listss = model('product_category')->where($sqlmap)->limit($limit)->order("listorder ASC")->select();
        $result = array();
        $rewrite = new \Common\Library\rewrite();
        $lists = array();
        foreach($listss as $k=>$v) {
            $r['url'] = $rewrite->category($v['catid']);
            $r['catname'] = $v['catname'];
            $r['catid'] = $v['catid'];
            $r['parentid'] = $v['parentid'];
            $r['arrparentid'] = $v['arrparentid'];
            $r['arrchildid'] = $v['arrchildid'];
            $r['child'] = $v['child'];/*是否存在子栏目，1存在*/
            $lists[$k] = $r;
        }
        $result = array();
        $result['status'] = 1;
        $result['lists'] = $lists;
       // var_dump($lists);
       echo json_encode($result);

    }

    public function goods_show(){
        $param = I('param.');
        extract($param);
        if (!$goods_id) $this->error('参数错误！');
        $factory = new \Product\Factory\product($goods_id);
        $rs = $factory->product_info;
        $lists = array();
        $lists['mod'] = $rs['mod'];
        $lists['status'] = $rs['status'];
        $lists['catid'] = $rs['catid'];
        $lists['start_time'] = $rs['start_time'];
        $lists['end_time'] = $rs['end_time'];
        $lists['title'] = $rs['title'];
        $lists['id'] = $rs['id'];
        $lists['source'] = $rs['source'];/*店铺来源*/
        $lists['type'] = $rs['type'];/*下单方式*/
        $lists['thumb'] = $rs['thumb'];
        $lists['url'] = $rs['url'];
        $lists['goods_content'] = $rs['goods_content'];
        $lists['goods_tips'] = $rs['goods_tips'];
        $lists['source'] = $rs['source'];
        $lists['type'] = $rs['type'];
        $lists['price_name'] = activitiy_price_name($rs['mod']);
        if ($rs['mod'] == 'rebate') {
                 $lists['price'] = $rs['goods_price']*$rs['goods_discount'];
                 $lists['goods_discount'] = $rs['goods_discount'];

            }
        $lists['goods_price'] = $rs['goods_price'];
        $lists['goods_tryproduct'] = $rs['goods_tryproduct'];
        $lists['goods_bonus'] = $rs['goods_bonus'];
        $lists['goods_number'] = $rs['goods_number'];
        $lists['number'] = $rs['goods_number'] - buyer_count_by_gid($rs['id']);//剩余份数
        $lists['hits'] = $rs['hits'];
            if ($rs['mod'] == 'trial') {
                
                if ($rs['goods_bonus'] > '0' && $rs['goods_bonus'] != '0.00') {
                    /*3:红包类型*/
                    $lists['protype'] = 3;
                }elseif($rs['goods_tryproduct'] > 0 && $rs['goods_tryproduct'] != ''){
                        /*w:拍a发b*/
                    $lists['protype'] = 2;
                }else{
                        /*1:实物专区*/
                    $lists['protype'] = 1;

                }

            }
        $lists['apply_people'] =  get_trial_by_gid($rs['id']);/*申请人数*/
        $lists['passed_people'] =  get_trial_pass_by_gid($rs['id']);/*已通过数量*/
        $lists['finish_people'] = get_over_trial_by_gid($rs['id']);/*已完成人数*/
        $lists['goods_deposit'] = $rs['goods_deposit'];
        $result = array();
        $result['lists'] = $lists;
        echo json_encode($result);

    }

    public function good_user_list(){
        $param = I('param.');
        extract($param);
        $state = $state ?$state:1;
        /*state     （1为已申请 2.为已通过 3.为已完成）*/
        if (!$goods_id || !$state)$this->error('参数错误！'); 
        $sqlmap = array();
        $sqlmap['goods_id'] = $goods_id;
        if ($state == 2) {
            $sqlmap['status'] = array('EQ',2);
        }else if($state == 3){
            $sqlmap['status'] = array('EQ',7);

        }
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }
        $factory = new \Product\Factory\product($goods_id);
        $order = model('order')->where($sqlmap)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($order as $k => $v) {
            $r['avatar'] = getavatar($v['buyer_id'],1);
            $r['nickname'] = nickname($v['buyer_id']);
            $r['apply_time'] = $v['create_time'];
            $lists[$k] = $r;
        }
        $result = array();
        $result['lists'] = $lists;
        //var_dump($lists);
       echo json_encode($result);
    }

   /*获取单个商品的晒单*/
    public function goods_report_lists(){
        $param = I('param.');
        extract($param);
        if (!$goods_id) $this->error('参数错误！'); 
        $sqlmap = array();
        $sqlmap['goods_id'] = $goods_id;
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }
        $report_lists = model('report')->where($sqlmap)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($report_lists as $k => $v) {
            $r['avatar'] = getavatar($v['userid'],1);
            $r['nickname'] = nickname($v['userid']);
            $r['report_imgs'] = $v['report_imgs'];
            $r['content'] = $v['content'];
            $lists[$k] = $r;
           
        }
        $result = array();
        $result['lists'] = $lists;
        //var_dump($lists);
       echo json_encode($result);


    }

    /*获取单个商品的试用报告*/
    public function trial_report_lists(){
        $param = I('param.');
        extract($param);
        if (!$goods_id) $this->error('参数错误！'); 
        $sqlmap = array();
        $sqlmap['goods_id'] =(int) $goods_id;
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }
        $trial_lists = model('trial_report')->where($sqlmap)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($trial_lists as $k => $v) {
            $r['avatar'] = getavatar($v['userid'],1);
            $r['nickname'] = nickname($v['userid']);
            $r['thumb'] = $v['thumb'];
            $r['content'] = $v['content'];
            $lists[$k] = $r;
           
        }
        $result = array();
        $result['lists'] = $lists;
        echo json_encode($result);
    }
    /*日赚任务列表*/
    public function broke_list(){
        $param = I('param.');
        extract($param);
        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
        $state = $state ? $state : 1;
         if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }
       
        $sqlmap['status'] = $state;
        $lists = array();
        $count = model('task_day')->where($sqlmap)->count();
        $task = model('task_day')->where($sqlmap)->page($page, $num)->order($orderby .' '. $orderway)->select();
        foreach ($task as $k => $v) {
            $lists[$k]['status'] = $v['status'];
            $lists[$k]['goods_number'] = $v['goods_number'];
            $lists[$k]['title'] = $v['title'];
            $lists[$k]['goods_price'] = $v['goods_price'];
            $lists[$k]['number'] = $v['goods_number']-$v['already_num'];
            $lists[$k]['already_num'] = $v['already_num'];
        }
        $pages = page($count, $num);
        $result = array();
        $result['lists'] = $lists;
        $result['count'] = $count;
        $result['pages'] = $pages;
        echo json_encode($result);
    }

     /*日赚任务详情*/
    public function broke_show(){
        $param = I('param.');
        extract($param);
        if(!$id)$this->error('参数错误！');
        $v = model('task_day')->where(array('id'=>$id))->find();
        $lists = array();
        $lists['status'] = $v['status'];
        $lists['goods_number'] = $v['goods_number'];
        $lists['title'] = $v['title'];
        $lists['goods_price'] = $v['goods_price'];
        $lists['number'] = $v['goods_number']-$v['already_num'];
        $lists['already_num'] = $v['already_num'];
        $result = array();
        $result['lists'] = $lists;
        echo json_encode($result);

    }

    /*购物返利参与条件(试客)（1为需要 0为不需要）*/
    public function check_authority(){
        $param = I('param.');
        extract($param);
        $lists = array();
        //$conditions = C_READ('buyer_good_buy_times','trial');
        $conditions = string2array(model('activity_set')->where(array('key'=>'buyer_join_condition','activity_type'=>$mod))->getField('value'));
        if ((int)$conditions['information']  == 6) {
            $lists['information'] = 1;
        }else{
            $lists['information'] = 0;
        }

        if ((int)$conditions['phone'] == 1) {
            $lists['phone'] = 1;
        }else{
            $lists['phone'] = 0;

        }

        if ((int)$conditions['email'] == 2) {
            $lists['email'] = 1;
        }else{
            $lists['email'] = 0;

        }

        if ((int)$conditions['realname'] == 3) {
            $lists['realname'] = 1;
        }else{
            $lists['realname'] = 0;

        }

        if ((int)$conditions['bind_taobao'] == 4) {
            $lists['bind_taobao'] = 1;
        }else{
            $lists['bind_taobao'] = 0;

        }

        if ((int)$conditions['bind_alipay'] == 5) {
            $lists['bind_alipay'] = 1;
        }else{
            $lists['bind_alipay'] = 0;

        }

        $lists['goods_count'] =  C_READ('buyer_good_buy_times',$mod);

        if ( C_READ('buyer_day_buy_times',$mod) == 0) {
            $lists['buy_count'] = '不限';
        }else{
            $lists['buy_count'] =  C_READ('buyer_day_buy_times',$mod);

        }
        if ( C_READ('buyer_buy_time_limit',$mod) == 0) {
            $lists['time_limit'] = '不限';
        }else{
            $lists['time_limit'] =  C_READ('buyer_buy_time_limit',$mod);

        }

       $result = array();
       $result['lists'] = $lists;
       echo json_decode($result);

    }

    /*10.获取网站幻灯片*/
    public function focus(){
        $param = I('param.');
        extract($param);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 3;
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }
        $sqlmap = array();
        $sqlmap['type'] = $type?$type:1;
        $focus = model('focus')->where($sqlmap)->order($orderby .' '. $orderway)->limit($num)->select();
        $lists = array();
        foreach ($focus as $k => $v) {
            if ($v['endtime'] == 0 || NOW_TIME < $v['endtime']) {
                $r['title'] = $v['title'];
                $r['image'] = $v['image'];
                $r['url'] = $v['url'];
                $r['endtime'] = date('Y-m-d',$v['endtime']);
                $lists[$k] = $r;
                
            }
        }
        echo json_encode($lists);

    }
/*11.获取用户信息*/
    public function get_userinfo(){
        $param = I('param.');
        extract($param);
        if (!$userid) $this->error('参数错误！');
        $userinfos = member_info($userid);
        $lists = array();
        $lists['userid'] = $userinfos['userid'];
        $lists['status'] = $userinfos['status'];
        $lists['nickname'] = $userinfos['nickname'];
        $lists['avatar'] = getavatar($userinfos['userid'],1);
        $lists['phone'] = $userinfos['phone'];
        $lists['email'] = $userinfos['email'];
        $lists['money'] = $userinfos['money'];
        $lists['point'] = $userinfos['point'];
        $lists['group_name'] = member_group_name($userinfos['userid']);
        $lists['phone_status'] = $userinfos['phone_status'];
        $lists['email_status'] = $userinfos['email_status'];
        $lists['alipay_status'] = $userinfos['email_status'];
        $lists['name_status'] = $userinfos['id_number_status'];
        echo json_encode($lists);
    }

/*获取用户绑定淘宝帐号*/
    public  function get_tbaccount(){
        $param = I('param.');
        $sqlmap = array();
        extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }

        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;

        if ($userid) {
            $sqlmap['userid'] = $userid;
        }
        if ($id) {
             $sqlmap['id'] = $id;
        }
        $count =  model('member_bind')->where($sqlmap)->count();
        $account = model('member_bind')->where($sqlmap)->page($page,$num)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($account as $k => $v) {
            $r['id'] = $v['id'];
            $r['account'] = $v['account'];
            $r['inputtime'] = $v['inputtime'];
            $r['updatetime'] = $v['updatetime'];
            $r['safe_grade'] = $v['safe_grade'];
            $r['bscore'] = $v['bscore'];
            $r['is_real_name'] = $v['is_real_name'];
            $r['is_default'] = $v['is_default'];
            $r['status'] = $v['status'];
            $lists[$k] = $r;

        }
        $pages = page($count, $num);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);

    }

    public function get_useraccount(){
        $param = I('param.');
        $sqlmap = array();
        extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }

        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
        if (!$userid) $this->error('请勿非法访问');

        if ($userid) {
            $sqlmap['userid'] = $userid;
        }
        if ($type) {
             $sqlmap['type'] = $type?$type:'alipay';
        }
        $count =  model('member_attesta')->where($sqlmap)->count();
        $account = model('member_attesta')->where($sqlmap)->page($page,$num)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($account as $k => $v) {
            $infos = string2array($v['infos']);
             $r['userid'] = $v['userid'];
             $r['id'] = $v['id'];
             $r['type'] = $v['type'];
          if ($v['type'] == 'alipay') {
               $r['account'] = $infos['alipay_account'];
               $r['username'] = $infos['username'];
              
          }elseif($v['type'] == 'bank'){
                $r['account'] = $infos['account'];
                $r['province'] = $infos['province'];
                $r['city'] = $infos['city'];
                $r['bank_name'] = $infos['bank_name'];
                $r['area'] = $infos['area'];
                $r['sub_branch'] = $infos['sub_branch'];
                //根据linkid查地址
                $province = model('linkage')->getFieldByLinkageid($infos['province'],'name');
                $city = model('linkage')->getFieldByLinkageid($infos['city'],'name');
                $r['band_address'] = $province.$city.$infos['sub_branch'];

          }
           
            $lists[$k] = $r;

        }
        $pages = page($count, $num);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);

        
    }

    /*获取用户订单信息*/
    public function getorderlists(){
        $param = I('param.');
        $sqlmap = array();
        extract($param);
        if ($orderby == '' || $orderway == '') {  
            $orderby ='id';
            $orderway = 'DESC';
        }

        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
        if (!$userid) $this->error('请问非法访问');

        if ($userid) {
            $sqlmap['buyer_id'] = $userid;
        }
        if ($mod) {
            $sqlmap['act_mod'] = $mod ?$mod:'trial';
        }
        if ($status) {

             if ((int)$status == -1) {
                 $sqlmap['status'] = array('IN','-1,0');
             }elseif($status == 1){
                 $sqlmap['status'] = array('IN','1,2,3,4,5,6,8');
             }elseif($status == 2){
                 $sqlmap['status'] = array('eq',7);
             }
        }
        $count =  model('order')->where($sqlmap)->count();
        $orders = model('order')->where($sqlmap)->page($page,$num)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($orders as $k => $v) {
            $r['id'] = $v['id'];
            $r['buyer_id'] = $v['buyer_id'];
            $r['goods_id'] = $v['goods_id'];
            $r['seller_id'] = $v['seller_id'];
            $r['inputtime'] = $v['inputtime'];
            $r['status'] = $v['status'];
            $r['check_time'] = $v['check_time'];
            $r['act_mod'] = $v['act_mod'];
            $r['order_sn'] = $v['order_sn'];
            $r['create_time'] = $v['create_time'];
            $r['complete_time'] = $v['complete_time'];
            $r['bind_id'] = $v['bind_id'];
            $r['is_vip_shi'] = $v['is_vip_shi']; 
            $factory = new \Product\Factory\product($v['goods_id']);    
            $r['title'] = $factory->product_info['title'];  
            $r['thumb'] = $factory->product_info['thumb']; 
            $r['goods_price'] = $factory->product_info['goods_price'];         
            $lists[$k] = $r;            
        }
 
        $pages = page($count, $num);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);

    }

    /*15.获取用户提现记录*/
    public function getusercashlog(){
        $param = I('param.');
        $sqlmap = array();
        extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='cashid';
            $orderway = 'DESC';
        }

        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
        if (!$userid) $this->error('请问非法访问');

        if ($userid) {
            $sqlmap['userid'] = $userid;
        }
        if ($paypal) {
           $sqlmap['paypal'] = $paypal;
        }
        
        $count =  model('cash_records')->where($sqlmap)->count();
        $cashs = model('cash_records')->where($sqlmap)->page($page,$num)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($cashs as $k => $v) {
            $r['userid'] = $v['userid'];
            $r['id'] = $v['cashid'];
            $r['inputtime'] = $v['inputtime'];
            if ($v['paypal'] == 1) {
                $r['paypal'] = '普通';
            }else{
                $r['paypal'] = '快速';
            }
            $r['status'] = $v['status'];
            $r['money'] = $v['money'];
            $r['fee'] = $v['fee'];
            $r['totalmoney'] = $v['totalmoney'];
            $r['account'] = $v['cash_alipay_username'];
            if ($v['type'] == 1) {
               $r['type'] = '银行';
            }elseif($v['type'] == 2){
                $r['type'] = '支付宝';
            }
            $r['check_time'] = $v['check_time'];
            $lists[$k] = $r;
            
        }

        $pages = page($count, $num);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);
    }

    /*获取用户账户明细*/
    public function getfinancelog(){
        $param = I('param.');
        $sqlmap = array();
        extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }

        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
        if (!$userid) $this->error('请问非法访问');

        if ($userid) {
            $sqlmap['userid'] = $userid;
        }
        if ($type) {
            if ($type == 1) {
                $sqlmap['type'] = 'money';
            }

            if ($type == 2) {
                $sqlmap['type'] = 'point';
            }
           
        }
        
        $count =  model('member_finance_log')->where($sqlmap)->count();
        $finances = model('member_finance_log')->where($sqlmap)->page($page,$num)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($finances as $k => $v) {
            $r['userid'] = $v['userid'];
            $r['id'] = $v['id'];
            $r['type'] = $v['type'];
          //  $r['num'] = $v['num'];
            $info = array();
            $info['userid'] = $v['userid'];
            $info['num'] = array('gt',0);
            $info['type'] = 'money';
            $r['total_num'] = model('member_finance_log')->where($info)->sum('num');
            $infos = array();
            $infos['userid'] = $v['userid'];
            $infos['num'] = array('lt',0);
            $infos['type'] = 'money';
            $r['total_desc'] = model('member_finance_log')->where($infos)->sum('num');
            $r['dateline'] = $v['dateline'];
            $r['cause'] = $v['cause'];  
            $lists[$k] = $r;
        }

        $pages = page($count, $num);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);



    } 

    /*获取站内信*/
    public function getmessage(){
        $param = I('param.');
        $sqlmap = array();
        extract($param);
        $type = (isset($type) && is_numeric($type)) ? $type : 1;
        if ($type == 1) {
             if ($orderby == '' || $orderway == '') {
            $orderby ='messageid';
            $orderway = 'DESC';
         }
        }else{
             if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
         }
        }
       

        $page = max(1, (int) $page);
        $num = (isset($num) && is_numeric($num)) ? abs($num) : 10;
       
        if (!$userid) $this->error('请问非法访问');

      /*  if ($userid) {
            $sqlmap['send_to_id'] = $userid;
        }*/

        if($type == 1){//私信
            $sqlMap = array();
            $sqlMap['send_to_id'] = $userid;
            $count= $this->message_db->where(array('send_to_id'=>$userid,'status'=>0))->count();
            $announce_count = $this->message_db->where($sqlMap)->count();
            $announce_lists = $this->message_db->where($sqlMap)->page(PAGE,10)->order($orderby .' '. $orderway)->select();
           // echo $this->message_db->getLastSql();
            $lists = array();
            foreach ($announce_lists as $k=>$v){
                $rs = model('message_data')->where(array('message_id'=>$v['messageid'],'userid'=>$userid))->find();
                
                $r['message_id'] = $v['messageid'];
                $r['isdelete'] = $rs['isdelete'];
                $r['send_to_id'] = $v['send_to_id'];
                $r['subject'] =  $v['subject'];
                $r['content'] =  $v['content'];
                $r['inputtime'] =  $v['message_time'];
                $r['status'] =  $v['status'];


                $lists[$k] = $r;
            }

          //  var_dump($announce_lists);
            $pages = showPage($announce_count,PAGE,10);
        }elseif($type == 2){//系统消息
            //查出当前会员的会员组
            $sqlMap = array();
            $count  = $this->mgroup_db->where(array('status'=>0))->count();
            $r = model('member')->where(array('userid'=>$userid,'modelid'=>1))->field('groupid')->find();
            $sqlMap['groupid'] = $r['groupid'];
            $announce_count = $this->mgroup_db->where($sqlMap)->count();
            $announce_lists = $this->mgroup_db->where($sqlMap)->page(PAGE,10)->order($orderby .' '. $orderway)->select();
            $lists = array();
                      //  echo $this->mgroup_db->getLastSql();

            foreach ($announce_lists as $k=>$v){
                $rs = model('message_data')->where(array('group_message_id'=>$v['id'],'userid'=>$userid))->find();
               // var_dump($rs['userid']);
                $announce_lists[$k]['group_id'] = $rs['group_message_id'];
                $announce_lists[$k]['isdelete'] = $rs['isdelete'];

                $r['message_id'] = $v['id'];
                $r['isdelete'] = $rs['isdelete'];
                $r['send_to_id'] = $rs['userid'];
                $r['subject'] =  $v['subject'];
                $r['content'] =  $v['content'];
                $r['inputtime'] =  $v['inputtime'];
                $r['status'] =  $v['status'];


                $lists[$k] = $r;
            }
            $pages = showPage($announce_count,PAGE,10);
        }elseif($type == 3){
            /**/
        }
      
      
        $pages = showPage($announce_count,PAGE,10);
        $result = array();
        $result['status'] = 1;
        $result['count'] = $announce_count;
        $result['count_status'] = $count;
        $result['lists'] = $lists;
        $result['pages'] = $pages;
        echo json_encode($result);


    }

    /**
     * 标注已读
     */
    public function read(){
        $ids = (array)$_POST['id'];
        if (!$ids) exit();
        $sqlMap = array();
        $type = I('type',1);
        if ($type == 1) {   //站内信
            $sqlMap['messageid'] = array('IN',$ids);
            $sqlMap['send_to_id'] = $this->userid;
            $result = $this->message_db->where($sqlMap)->save(array('status'=>1));
            if (!$result) $this->error('标记失败');
            $this->success('标记成功');
        }else{  //  群发短消息
            foreach ($ids as $k => $id) {
                unset($sqlMap);
                $sqlMap['userid'] = $this->userid;
                $sqlMap['group_message_id'] = $id;          
                $count = model('message_data')->where($sqlMap)->count();
                if (!$count) {
                    $result = model('message_data')->add($sqlMap);
                }
            }           
            if (!$result) $this->error('标记失败');
            $this->success('标记成功');
        }       
    }


    /*获取帮助中心*/
    public  function gethelplist(){
        $param = I('param.');
        extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='catid';
            $orderway = 'DESC';
        }
       
        if ($catid) {
             $sqlmap['parentid'] = array('EQ',$catid);

        }else{
             $sqlmap['parentid'] = array('EQ',1);
        }
       
        $category = model('category')->where($sqlmap)->order($orderby .' '. $orderway)->select();
        $lists = array();
        foreach ($category as $k => $v) {
            $r['catname'] = $v['catname'];
            $r['parentid'] = $v['parentid'];
            $r['catid'] = $v['catid'];
            $r['parentid'] = $v['parentid'];
            $r['arrchildid'] = $v['arrchildid'];
            $lists[$k] = $r;
        }
 //var_dump($lists);
         echo json_encode($lists);
        

    }

    /*获取文章列表*/
    public function getcatidlist(){
        $param = I('param.');
        extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='catid';
            $orderway = 'DESC';
        }
       if (!$catid) $this->error('参数错误！');
       $sqlmap = array();
       $sqlmap['catid'] = $catid;
       $lists = model('article')->where($sqlmap)->order($orderby .' '. $orderway)->select();
       foreach ($lists as $k => $v) {
           $lists[$k]['title'] = $v['title'];
           $lists[$k]['id'] = $v['id'];
           $lists[$k]['description'] = $v['description'];
           $hit = model('category')->find($v['catid']);
           $lists[$k]['hits'] = $hit['hits'];

       }

     //  var_dump($lists);

     echo  json_encode($lists);

    }

    public function helpshow(){
        $param = I('param.');
         extract($param);
        if ($orderby == '' || $orderway == '') {
            $orderby ='id';
            $orderway = 'DESC';
        }
       if (!$id) $this->error('参数错误！');
       $sqlmap = array();
       $sqlmap['id'] = $id;
       $lists = model('article_data')->where($sqlmap)->order($orderby .' '. $orderway)->field('id,content')->find();
   
       $article = model('article')->find($lists['id']);
       $lists['description'] =  $article['description'];
       $lists['title'] =  $article['title'];
       $hit = model('category')->find($article['catid']);
       $lists['hits'] = $hit['hits'];
       echo json_encode($lists);

    }

    public function check_phone_exsit(){
        $phone = I('phone');
        $count = model('member')->where(array('phone'=>$phone))->count();
        if ($count > 0) {
            $this->json_function(0,'手机号已被占用');    
            return FALSE;
               
        }else{
            $this->json_function(1,'手机号可用');                   
        }

    }

    public function send_phone_code(){
        $result = array();

        $mobile = I('phone');
         if(is_mobile(trim($mobile)) != TRUE) {
            $this->json_function(0,'手机号格式错误！');
            return FALSE;
            
        }
        
        /* 手机号码已被注册的不能发送短信 */
        if(model('member')->where(array('phone' => $mobile))->count() > 0) {
            $this->json_function(0,'该手机号已被占用');
            return FALSE;

        }

        $beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
        $endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $sqlmap = array();
        $sqlmap['posttime'] = array('between',array($beginToday,$endToday));
        $sqlmap['mobile'] = $mobile;
        $sqlmap['enum'] = 'register';
        $count = model('sms_report')->where($sqlmap)->count();

        $conditions = array();
        $conditions['posttime'] = array('between',array($beginToday,$endToday));
        $conditions['ip'] = get_client_ip();
        $ip_count = model('sms_report')->where($conditions )->count();

        if (intval($count) > 3) {
            $this->json_function(0,'同一号码，每天只能发送3次，请明日再尝试');
            return FALSE;

        }

        /* 检测当前手机的发送日期 */
        $_vcode = random(6, 1);
        $msg = '感谢您注册,您的验证码为'.$_vcode;
        $SmsApi = new \Sms\Api\SmsApi();
       $result = $SmsApi->send($mobile, $msg);
        //$result = TRUE;
        if(!$result) {
            $this->json_function(0,'手机短信发送失败，请重试。');
            return FALSE;

        } else {
            $info = array();
            $info['mobile'] = $mobile;
            $info['posttime'] = NOW_TIME;
            $info['id_code'] = $_vcode;
            $info['msg'] = $msg;
            $info['ip'] = get_client_ip();
            $info['enum'] = 'register';
            model('sms_report')->update($info);
            $this->json_function(1,'发送成功');
        }

    }


     public function register_check_sms($isyes = TRUE) {
        $mobile = I('phone');
        $sms = I('sms');

        if(empty($mobile) || !is_mobile($mobile)) {
            $this->json_function(0,'手机号码为空或格式错误');
            return FALSE;
        }
        if(empty($sms)) {
            $this->json_function(0,'手机短信验证码不能为空');
            return FALSE;
        }
        $sqlmap = array();
        $sqlmap['mobile'] = $mobile;
        $sqlmap['id_code'] = $sms;
        $sqlmap['status'] = 0;
        if(model('sms_report')->where($sqlmap)->count() < 1) {
            $this->json_function(0,'验证码输入错误');
            return FALSE;
        }
        if($isyes === TRUE) {
            model('sms_report')->where($sqlmap)->setField('status', 1);
        }
        $this->json_function(1,'验证码输入正确');
    }


        /* 检测验证码是否正确 */
    public function public_checkverify_ajax() {
        $verify = I('verify');
        $verify = strtolower($verify);
        if(checkVerify($verify, FALSE) == TRUE) {
            $this->json_function(1,'验证码输入正确');
        } else {
            $this->json_function(0,'验证码输入错误');
            return FALSE;

        }
    }


    /*获取验证码*/
    public function get_verify(){
         $verify = A('Api/Verify');
         $results = $verify->create();
         $this->json_function(1,'获取成功',$results);

    }

    public function json_function($status,$msg,$data=''){
        $result = array();
        $result['status'] = $status;
        $result['msg'] = $msg;
        $result['data'] = $data;
        echo json_encode($result);                       

    }




}
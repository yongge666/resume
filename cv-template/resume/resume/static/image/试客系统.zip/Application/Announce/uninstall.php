<?php
$sqlquery = <<<EOT
DROP TABLE IF EXISTS `prefix_announce`;

EOT;
?>
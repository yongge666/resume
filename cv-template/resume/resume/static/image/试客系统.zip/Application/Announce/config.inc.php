<?php
defined('IN_ADMIN') or exit('Access Denied');
$module = 'Announce';
$modulename = '公告模块';
$introduce = '公告模块';
$author = 'TPCMS Team';
$authorsite = 'http://www.xuewl.cn';
$authoremail = 'master@xuewl.com';
?>

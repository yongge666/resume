<?php
/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2013, Chongqing Zero Technology Co. Ltd.
 * @link           http://www.xuewl.com
**/
define('IN_ADMIN', TRUE);
// $_GET['m'] = 'Admin';
// require './index.php';
header("Location:index.php?m=Admin");
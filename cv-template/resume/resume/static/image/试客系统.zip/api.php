<?php
$_GET['m'] = 'Pay';
$_GET['c'] = 'Index';
$_GET['a'] = 'callback';
require './index.php';
?>